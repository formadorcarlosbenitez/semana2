/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.ejerciciosemana5.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author santi
 */
public class ProductoDB {

    public String url = "";
    public Connection con;
    public Statement stmt;
    public ResultSet rs;

    public ProductoDB() {
        url = "jdbc:sqlite:datos.db";
        try {
            con = DriverManager.getConnection(url);
            System.out.println("Se conecto con la base de datos");
        } catch (SQLException ex) {
            System.out.println("No hay una conexion con la base de datos " + ex.getMessage());
        }
        
        cerrarConexion();
        
        
    }

    public void cerrarConexion() {
        if (con != null) {
            try {
                con.close();
                System.out.println("Se cerro la base de datos");
            } catch (SQLException ex) {
                System.out.println("No se logro cerrar la conexion con la bd");
            }
        }
    }

}
