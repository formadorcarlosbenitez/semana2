/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.ejerciciosemana5.dao;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author santi
 */
public class ConexionDB {

    private String url = "jdbc:sqlite:datos.db";
    public Connection conexion;
    private Statement sentencia;
    private ResultSet resultadosConsulta;

    public ConexionDB() {

        try {
            conexion = DriverManager.getConnection(url);
            DatabaseMetaData meta = conexion.getMetaData();
            System.out.println("Base de datos conectada! \n" + meta.getDriverName());
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

    }

    public void cerrarConexion() {
        if (conexion != null) {
            try {
                conexion.close();
                System.err.println("Se cerro la conexion con la base de datos!");
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    public boolean crear(String textoSentencia) {
        try {
            sentencia = conexion.createStatement();
            sentencia.execute(textoSentencia);
            return true;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return false;
        }
    }

    public ResultSet consultar(String textoSentencia) {
        try {
            sentencia = conexion.createStatement();
            resultadosConsulta = sentencia.executeQuery(textoSentencia);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return resultadosConsulta;
    }

}
