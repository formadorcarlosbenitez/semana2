/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.ingcarlos.ejerciciosemana5;

import com.ingcarlos.ejerciciosemana5.dao.ProductoDB;

/**
 *
 * @author santi
 */
public class EjercicioSemana5 {

    public static void main(String[] args) {
        ProductoDB pdb = new ProductoDB();
    }
}
