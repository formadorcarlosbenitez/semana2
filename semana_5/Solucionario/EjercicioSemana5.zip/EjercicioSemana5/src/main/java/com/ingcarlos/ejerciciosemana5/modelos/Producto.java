/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.ejerciciosemana5.modelos;

/**
 *
 * @author santi
 */
public class Producto {
    
    public int id;
    public String nombre;
    public int cantidad;
    public int precio;
    public String categoria;

    public Producto(int id, String nombre, int cantidad, int precio, String categoria) {
        this.id = id;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.categoria = categoria;
    }
    
    
    
}
