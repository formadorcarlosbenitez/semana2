/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.ejerciciosemana5.modelos;

import com.ingcarlos.ejerciciosemana5.dao.ConexionDB;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author santi
 */
public class Producto {

    public int id;
    public String nombre;
    public int cantidad;
    public int precio;
    public String categoria;

    public Producto(int id, String nombre, int cantidad, int precio, String categoria) {
        this.id = id;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.categoria = categoria;
    }

    public Producto(String nombre, int cantidad, int precio, String categoria) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.categoria = categoria;
    }

    public Producto() {
    }

    public void save() {
        ConexionDB c = new ConexionDB();
        String sql = "INSERT INTO productos(nombre, cantidad, precio, categoria)\n"
                + "VALUES ('" + nombre + "', " + cantidad + ", " + precio + ", '" + categoria + "');";
        c.crear(sql);
        c.cerrarConexion();
        System.out.println(sql);
    }

    public List<Producto> getProductos() {
        ConexionDB conexion = new ConexionDB();
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos;";
        Producto p;
        try {
            ResultSet rs = conexion.consultar(sql);
            while (rs.next()) {
                p = new Producto();
                p.id = rs.getInt("id");
                p.nombre = rs.getString("nombre");
                p.cantidad = rs.getInt("cantidad");
                p.precio = rs.getInt("precio");
                p.categoria = rs.getString("categoria");
                lista.add(p);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        conexion.cerrarConexion();
        return lista;
    }

}
