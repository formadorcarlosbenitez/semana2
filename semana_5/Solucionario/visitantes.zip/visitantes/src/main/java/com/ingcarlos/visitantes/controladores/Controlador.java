/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.visitantes.controladores;

import com.ingcarlos.visitantes.modelos.Visitante;
import com.ingcarlos.visitantes.vistas.Ventana;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author santi
 */
public class Controlador {
    
    public Ventana ventana;
    DefaultTableModel modeloTabla;

    public Controlador(Ventana ventana) {
        this.ventana = ventana;
        String[] titulos = {"Cédula","Nombres","Apellidos","Correo"};
        modeloTabla = new DefaultTableModel(titulos, 0);
        this.ventana.tablaResumen.setModel(modeloTabla);
        this.ventana.btnRegistrar.addActionListener(new ButtonRegistrarListener());
    }
    
    class ButtonRegistrarListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            Visitante v = new Visitante( Long.parseLong(ventana.txtCedula.getText()) , 
            ventana.txtNombres.getText(), 
            ventana.txtApellidos.getText(), 
            ventana.txtCorreo.getText());
        
            Object[][] arreglo = { {"bogota", "bmanga"} , {}, {}};

            modeloTabla.addRow( new Object[]{v.cedula,v.nombres,v.apellidos,v.correo} );

            ventana.txtCedula.setText("");
            ventana.txtNombres.setText("");
            ventana.txtApellidos.setText("");
            ventana.txtCorreo.setText("");
        }
        
    }
    
    
}
