/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.ingcarlos.visitantes.modelos;

/**
 *
 * @author santi
 */

public class Visitante {
    public long cedula;
    public String nombres;
    public String apellidos;
    public String correo;

    public Visitante(long cedula, String nombres, String apellidos, String correo) {
        this.cedula = cedula;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.correo = correo;
    }
    
    
}
