/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.ejerciciosemana5.modelos;

import com.ingcarlos.ejerciciosemana5.dao.ConexionDB;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author santi
 */
public class Producto {

    public int id;
    public String nombre;
    public int cantidad;
    public int precio;
    public String categoria;
    private ConexionDB conexion;

    public Producto(int id, String nombre, int cantidad, int precio, String categoria) {
        this.id = id;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.categoria = categoria;
        conexion = new ConexionDB();
    }

    public Producto(String nombre, int cantidad, int precio, String categoria) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.categoria = categoria;
    }

    public Producto() {
        conexion = new ConexionDB();
    }

    public void save() {
        String sql = "INSERT INTO productos(nombre, cantidad, precio, categoria)\n"
                + "VALUES ('" + nombre + "', " + cantidad + ", " + precio + ", '" + categoria + "');";
        conexion.crear(sql);
        conexion.cerrarConexion();
    }

    public List<Producto> getProductos() {

        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos;";
        try {
            ResultSet rs = conexion.consultar(sql);
            while (rs.next()) {
                lista.add(new Producto(rs.getInt("id"), rs.getString("nombre"),
                        rs.getInt("cantidad"), rs.getInt("precio"), rs.getString("categoria")));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        conexion.cerrarConexion();
        return lista;

    }

    public void update() {
        String sql = "UPDATE productos\n"
                + "SET nombre = '" + nombre + "', cantidad = " + cantidad
                + ", precio = " + precio + ", categoria= '" + categoria + "'\n"
                + "WHERE id = "+id+";";
        conexion.actualizar(sql);
        conexion.cerrarConexion();
    }
    
    public void delete(){
        String sql = "DELETE FROM productos WHERE id="+id+";";
        conexion.borrar(sql);
        conexion.cerrarConexion();
    }

}
