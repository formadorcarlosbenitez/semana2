
import com.ingcarlos.ejerciciosemana5.modelos.Producto;
import org.junit.jupiter.api.Test;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author santi
 */
public class Pruebas {

    @Test
    public void testMetodoInsert() {

        Producto p = new Producto("Pan",15,500,"Verduras");
        p.save();
        double a = 1.000000001;
        String  s = String.format( "%.2f", a );
        System.out.println(s);
    }

}
