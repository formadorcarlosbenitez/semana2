/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.ingcarlos.introducciongui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Action;
import javax.swing.JButton;


/**
 *
 * @author santi
 */
public class IntroduccionGUI{
    
    JButton btn1;
    JButton btn2;
    javax.swing.JFrame ventana;
    
    public IntroduccionGUI(){
        go();
    }
    
    public void go(){
        ventana = new javax.swing.JFrame("Mi primera ventana");
        ventana.setSize(300, 300);
        ventana.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
        
        Container contenido = ventana.getContentPane();
        
        btn1 = new JButton("Click aqui 1");
        btn2 = new JButton("Click aqui 2");
        
        contenido.add(btn1, BorderLayout.NORTH);
        contenido.add(btn2, BorderLayout.SOUTH);
        
        ventana.setContentPane(contenido);
        
        btn1.addActionListener(new ButtonListener1());
        btn2.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) {
                btn1.setText("Has dado click aqui");
            }
        } );
        
    }
    
    class ButtonListener1 implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            btn1.setText("Has dado click aqui");
        }
    }
    class ButtonListener2 implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("Hola");
        }
    }
    
}

