/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.introducciongui;

/**
 *
 * @author santi
 */
public class Go {
    
    public static void main(String[] args) {
       IntroduccionGUI gui = new IntroduccionGUI();
       
    }
    
}
