/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.ingcarlos.libreria;

/**
 *
 * @author santi
 */
public class EjercicioModAcceso {

    public static void main(String[] args) {
        Libreria libreria = new Libreria("oreally");
        libreria.addLibro("Head First Java");
        libreria.addLibro("El amor en los tiempos del cólera");
        libreria.addLibro("La divina comedia");
        System.out.println("La cantidad de libros es: " + libreria.calcularCantidad());
        libreria.imprimirLibros();
    }
}
