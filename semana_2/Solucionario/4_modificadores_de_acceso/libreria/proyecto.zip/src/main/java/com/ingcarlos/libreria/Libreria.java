/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.libreria;

/**
 *
 * @author santi
 */
public class Libreria {

    private String nombre;
    private int cantidadLibros;
    private String[] libros = new String[10];

    public Libreria(String nombre) {
        this.nombre = nombre;

    }

    public void addLibro(String libro) {

        int i = 0;
        while (libros[i] != null && i < 10) {
            i++;
        }
        libros[i] = libro;
    }

    public int calcularCantidad() {

        int cantidad = 0;
        for (int i = 0; i < libros.length; i++) {
            if (libros[i] != null) {
                cantidad++;
            } else {
                break;
            }

        }

        return cantidad;

    }

    public void imprimirLibros() {
        System.out.println("Libros:");
        for (String libro : libros) {
            if (libro != null) {
                System.out.println(libro);
            }
        }
    }

}
