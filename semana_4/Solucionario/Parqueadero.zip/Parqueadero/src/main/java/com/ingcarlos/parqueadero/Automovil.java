/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.parqueadero;

/**
 *
 * @author santi
 */
public class Automovil extends Vehiculo implements Valuable{

    private String placa;

    public Automovil(String color, String placa, int tiempoEnParqueadero) {
        super.setColor(color);
        this.tiempoEnParqueadero = tiempoEnParqueadero;
        this.placa = placa;
    }
    
    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
    
    @Override
    public int calcularPrecio(){
        int precio = 4000;
        return tiempoEnParqueadero * precio;
    }
    
}
