/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.parqueadero;

/**
 *
 * @author santi
 */
public class Motocicleta extends Vehiculo implements Valuable{
    
    private String placa;

    public Motocicleta(String color, String placa, int tiempo) {
        setColor(color);
        this.placa = placa;
        tiempoEnParqueadero = tiempo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
    
    @Override
    public int calcularPrecio(){
        int precio = 2000;
        return tiempoEnParqueadero * precio;
    }

    @Override
    public String toString() {
        return  placa;
    }
    
    
    
    
}
