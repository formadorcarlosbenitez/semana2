/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.parqueadero;

/**
 *
 * @author santi
 */
public class Prueba {
       public static void main(String[] args) {
       Parqueadero p = new Parqueadero();
       p.nombreEstablecimiento = "MiParking";
       p.addVehiculo(new Motocicleta("azul","zzz-10z",2));
       p.addVehiculo(new Motocicleta("verde","aaa-10z",1));
       p.addVehiculo(new Motocicleta("azul","ccc-10z",1));
       p.addVehiculo(new Motocicleta("azul","sss-10z",1));
       p.addVehiculo(new Motocicleta("azul","jjj-11z",2));
       p.addVehiculo(new Bicicleta("gris",4));
       p.addVehiculo(new Bicicleta("negra",2));
       p.addVehiculo(new Bicicleta("rojo",6));
       p.addVehiculo(new Automovil("celeste","lll-106",8));
       p.addVehiculo(new Automovil("negro","ooo-117",10));
       p.imprimir();
  }
}
