/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.ingcarlos.parqueadero;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author santi
 */
public class Parqueadero {
    
    public String nombreEstablecimiento;
    public int plazasAutomovilDisponibles = 5;
    public int plazasMotoDisponibles = 10;
    public ArrayList<Automovil> automoviles = new ArrayList<>();
    public ArrayList<Motocicleta> motocicletas = new ArrayList<>();
    public List<Bicicleta> bicicletas = new ArrayList<>();
    public int ingresos = 0;
    
    public void addVehiculo(Vehiculo v){
        Valuable v2 = (Valuable)v;
        ingresos = ingresos + v2.calcularPrecio();
        if (v instanceof Bicicleta){
            bicicletas.add((Bicicleta)v);
        } else if (v instanceof Motocicleta) {
            motocicletas.add((Motocicleta)v);
        } else {
            automoviles.add((Automovil)v);
        }
    }
    
    public void imprimir(){
        System.out.println("Parqueadero \""+nombreEstablecimiento+"\", ingresos registrados $"+ingresos+", vehiculos:\n" +
            "Motos "+motocicletas+"\n" +
            "Bicicletas "+bicicletas+"\n" +
            "Automoviles "+automoviles );
    }
}
