/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.parqueadero;

/**
 *
 * @author santi
 */
public class Bicicleta extends Vehiculo implements Valuable{

    public Bicicleta(String color, int tiempo) {
        setColor(color);
        tiempoEnParqueadero = tiempo;
    }
    
    @Override
    public int calcularPrecio(){
        return 0;
    }
    
}
