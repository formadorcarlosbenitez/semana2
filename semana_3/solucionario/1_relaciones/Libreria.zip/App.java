

public class App
{
    public static void main(String[] args){
        Libreria libreria = new Libreria("Panamericana");
        libreria.addLibro(new Libro("Head First Java",722,"Kathy Sierra & Bert Bates"));
        libreria.addLibro(new Libro("El amor en los tiempos del cólera",490,"Gabriel García Marquez"));
        libreria.addLibro(new Libro("La divina comedia",274,"Dante Alighieri"));
        libreria.imprimirLibros();
    }
}
