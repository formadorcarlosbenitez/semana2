public class Libro
{
    private String nombre;
    private int paginas;
    private String autor;
    
    public Libro(String nombre, int paginas, String autor){
        
        this.nombre = nombre;
        this.paginas = paginas;
        this.autor = autor; 
        
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public int getPaginas(){
        return paginas;
    }
    
    public String getAutor(){
        return autor;
    }
}
