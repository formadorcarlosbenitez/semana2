public class Libreria{
    
    private String nombre;
    private int cantidadLibros;
    private Libro[] libros = new Libro[10];
    
    public Libreria(String nombre){
        this.nombre = nombre;
    }
    
    public void addLibro(Libro libro){
        
        for ( int i = 0; i<10 ; i++ ){
            if (libros[i] == null){
                libros[i] = libro;
                break;
            }
        }
    }
    
    public int calcularCantidad(){
        
        int cantidad = 0;
        
        for ( int i = 0; i<10 ; i++ ){
            if (libros[i] == null){
                break;
            }
            cantidad++;
        }
        
        cantidadLibros = cantidad;
        return cantidad;
        
    }
    
    public void imprimirLibros(){
        int cant = calcularCantidad();
        System.out.println("[Libreria "+nombre+", "+this.cantidadLibros+" libros]:");
        for (Libro elemento : libros){
            if( elemento == null) {
                break;
            }
            System.out.println("Título: "+elemento.getNombre()+", páginas: "+elemento.getPaginas()+", autor: "+elemento.getAutor() );
        }
    }
    
}
