
/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Main
{
    public static void main(String[] args)
    {
        Cuenta cuenta1 = new Cuenta(123456, 'A', 5000000, new Persona(100200300, "Torres C."));
        Cuenta cuenta2 = new Cuenta(654321, 'A', 2200000, new Persona(999999, "Rodriguez P."));
        cuenta1.ingreso(750000);
        cuenta1.egreso(4200000);
        
        // Test transfer()
        cuenta1.transferTo(cuenta2, 800000); 
    }
}
