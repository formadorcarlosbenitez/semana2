
/**
 * Write a description of class Cuenta here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cuenta
{
    protected int numeroCuenta;
    protected char tipoCuenta; // 'A' ahorros, 'C' corriente
    protected float fondos;
    protected Persona cliente;

    /**
     * Constructor for objects of class Cuenta
     */
    public Cuenta(int numeroCuenta, char tipoCuenta, float fondos, Persona persona)
    {
        this.numeroCuenta = numeroCuenta;
        this.tipoCuenta = tipoCuenta;
        this.fondos = fondos;
        cliente = persona;
    }

       public float ingreso(float cantidad){
        fondos += cantidad;
        imprimirMovimiento();
        return fondos;
    }
    
    public float egreso(float cantidad){
        fondos -= cantidad;
        boolean negativo = checkFondos();
        if (negativo){
            System.out.println("Error, los fondos son negativos");
        }
        imprimirMovimiento();
        return fondos;
    }
    
    public boolean checkFondos(){
        if (fondos < 0){
            return true;
        } else {
            return false;
        }
    }
    
    public void transferTo(Cuenta account, float cantidad){
        egreso(cantidad);
        account.ingreso(cantidad);
    }
    
    public void imprimirMovimiento(){
        System.out.println("Cuenta[numero: "+numeroCuenta+", fondos: "+fondos+" , apellidos cliente"+cliente.apellidos+"]");
    }
}
