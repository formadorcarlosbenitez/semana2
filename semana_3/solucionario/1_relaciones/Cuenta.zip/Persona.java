public class Persona {
    
    protected int cedula;
    protected String apellidos;

    public Persona(int cedula, String apellidos){
        this.cedula = cedula;
        this.apellidos = apellidos;
    }

}
