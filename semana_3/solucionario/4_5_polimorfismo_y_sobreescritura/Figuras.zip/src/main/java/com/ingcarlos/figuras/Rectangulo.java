/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.figuras;

/**
 *
 * @author santi
 */
public class Rectangulo extends Figura{
    
    protected  double largo = 1.0;
    protected double ancho = 1.0;

    public Rectangulo(double largo, double ancho) {
        this.largo = largo;
        this.ancho = ancho;
    }

    public Rectangulo() {
    }
    
    @Override
    public void calcularArea() {
        area = largo*ancho;
        System.out.println("El área del rectangulo es: " + area);
    }

    @Override
    public void calcularPerimetro() {
        perimetro = 2*(largo + ancho);
        System.out.println("El perimetro del rectangulo es: " + perimetro);
    }
    
}
