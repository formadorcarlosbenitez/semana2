/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.ingcarlos.figuras;

/**
 *
 * @author santi
 */
public class Figura {

    protected double area;
    protected double perimetro;
    protected String color = "red";

    public Figura() {
    }

    public Figura(String color) {
        this.color = color;
    }

    public void calcularArea() {

    }

    public void calcularPerimetro() {
            
    }

    @Override
    public String toString() {
        return "Figura{" + "area=" + area + ", perimetro=" + perimetro + ", color=" + color + '}';
    }
    
    

}
