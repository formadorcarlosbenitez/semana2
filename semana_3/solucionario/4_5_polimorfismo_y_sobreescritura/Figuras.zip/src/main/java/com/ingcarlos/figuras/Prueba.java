/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.figuras;

/**
 *
 * @author santi
 */
public class Prueba {
    public static void main(String[] args)
    {
        
        
        
        Circulo circulo = new Circulo(2.0);
        Circulo circulo2 = new Circulo(2.0);
        Rectangulo rectangulo = new Rectangulo(7,4);
        Cuadrado cuadrado = new Cuadrado(5);
        
        Object[] figuras = new Object[4];
        
       figuras[0] = circulo;
       figuras[1] = rectangulo;
       figuras[2] = cuadrado;
       figuras[3] = circulo2;
       
       
       System.out.println("El objeto es: " + rectangulo);
        
       if (figuras[0].equals(figuras[3])){
           System.err.println("Las figuras son iguales");
       }
       else {
           System.err.println("Las figuras NO son iguales");
       }
       
       
        Figura fig;
        for ( Object f : figuras ){
            fig = (Figura) f;
            fig.calcularArea();
            fig.calcularPerimetro();
        }
        
        // Calculos
        /*circulo.calcularArea();
        rectangulo.calcularArea();
        cuadrado.calcularArea();
        circulo.calcularPerimetro();
        rectangulo.calcularPerimetro();
        cuadrado.calcularPerimetro();*/
    }
}
