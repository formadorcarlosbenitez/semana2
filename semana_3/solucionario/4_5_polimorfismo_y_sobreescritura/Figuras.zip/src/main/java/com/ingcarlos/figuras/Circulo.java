/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.figuras;

/**
 *
 * @author santi
 */
public class Circulo extends Figura {

    protected double radio = 1.0;

    public Circulo(double radio) {
        this.radio = radio;
    }

    public Circulo() {

    }

    @Override
    public void calcularArea() {
        area = Math.PI*Math.pow(radio,2);
        System.out.println("El área del circulo es: " + area);
    }

    @Override
    public void calcularPerimetro() {
        perimetro = 2*Math.PI*radio;
        System.out.println("El perimetro del circulo es: " + perimetro);
    }

}
