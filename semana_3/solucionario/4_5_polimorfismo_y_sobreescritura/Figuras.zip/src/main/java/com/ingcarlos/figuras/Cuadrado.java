/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.figuras;

/**
 *
 * @author santi
 */
public class Cuadrado extends Rectangulo {

    protected double lado = 1.0;

    public Cuadrado() {
    }

    public Cuadrado(double lado) {
        this.lado = lado;
    }

    @Override
    public void calcularArea() {
        area = lado * lado;
        System.out.println("El área del cuadrado es: " + area);
    }

    @Override
    public void calcularPerimetro() {
        perimetro = 4 * lado;
        System.out.println("El perimetro del cuadrado es: " + perimetro);
    }

}
