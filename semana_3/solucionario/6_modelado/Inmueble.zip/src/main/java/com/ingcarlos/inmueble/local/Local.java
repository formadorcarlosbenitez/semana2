/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.inmueble.local;

import com.ingcarlos.inmueble.Inmueble;

/**
 *
 * @author santi
 */
public class Local extends Inmueble{
    public String localizacion;
}
