/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.inmueble.apartamento;

/**
 *
 * @author santi
 */
public class ApartamentoFamiliar extends Apartamento {

    public int valorAdministracion;

    public ApartamentoFamiliar(int identificadorInmobiliario, int area, String direccion, 
            int numeroHabitaciones, int numeroBanos, int valorAdministracion) {
        super.identificadorInmobiliario = identificadorInmobiliario;
        super.area = area;
        super.direccion = direccion;
        super.numeroHabitaciones = numeroHabitaciones;
        super.numeroBanos = numeroBanos;
        super.valorArea = 2000000;
        this.valorAdministracion = valorAdministracion;
    }
   

}
