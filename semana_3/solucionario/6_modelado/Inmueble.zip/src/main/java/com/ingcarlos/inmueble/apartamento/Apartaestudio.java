/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ingcarlos.inmueble.apartamento;

/**
 *
 * @author santi
 */
public class Apartaestudio extends Apartamento{

    public Apartaestudio(int identificadorInmobiliario, int area, String direccion, 
            int numeroHabitaciones, int numeroBanos) {
        super.identificadorInmobiliario = identificadorInmobiliario;
        super.area = area;
        super.direccion = direccion;
        super.numeroHabitaciones = numeroHabitaciones;
        super.numeroBanos = numeroBanos;
        super.valorArea = 1500000;
    }
    
}
