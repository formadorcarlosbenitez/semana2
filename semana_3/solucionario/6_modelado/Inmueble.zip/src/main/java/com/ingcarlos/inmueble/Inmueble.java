/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.ingcarlos.inmueble;

/**
 *
 * @author santi
 */
public class Inmueble {
    
    public int identificadorInmobiliario;
    public int area;
    public String direccion;
    public int precioVenta;
    public int valorArea;
    
    public void imprimir() {
        System.out.println("Identificador inmobiliario = " +
        identificadorInmobiliario);
        System.out.println("Area = " + area);
        System.out.println("Dirección = " + direccion);
        System.out.println("Precio de venta = $" + precioVenta);
    }
    
    public void calcularPrecioVenta(int valorArea){
        precioVenta = area * valorArea;
    }
    
}
