
/**
 * Write a description of class Hipopotamo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hipopotamo extends Animal
{
     public void makeNoise()
    {
       
    }
    public void eat()
    {
       
    }
    public void sleep()
    {
       
    }
}
