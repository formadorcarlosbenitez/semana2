
/**
 * Write a description of class Animal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Animal
{
    private int edad;

    /**
     * Constructor for objects of class Animal
     */
    public Animal()
    {
      
    }
    //GET
    public int getEdad(){
        return edad;
    }
    //SET
    public void setEdad(int edad){
        this.edad = edad;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void makeNoise()
    {
       
    }
    public void eat()
    {
       
    }
    public void sleep()
    {
       
    }
}
