
/**
 * Write a description of class Lobo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lobo extends Animal
{
    public Lobo()
    {
        
    }

}
