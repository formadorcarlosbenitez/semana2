
/**
 * Write a description of class Leon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Leon extends Felino
{
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public Leon(){
        this.
    }
}
